Release Notes
=============

Release notes from various versions of South.

.. toctree::
   :maxdepth: 1
   
   0.7
   0.7.1
   0.7.2