# version number
version_string = "1.0.7.348"
version = (1, 0, 7, 348)
